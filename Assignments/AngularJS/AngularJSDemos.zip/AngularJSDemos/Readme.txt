VISUAL STUDIO OPTION:

The Visual Studio 2013 solution is designed to run with IIS Express. To open it follow these steps:

1. Start Visual Studio 2013
2. Select File --> Open Website and select the AngularJSDemos folder
3. Right-click on the website project and ensure that IIS Express is being used as the server.

You should be all set.



NODE.JS OPTION:

If you want to run the site using Node.js (install it from http://nodejs.org) run the following at the command-prompt from within the AngularJSDemos folder:

node server.js

Now navigate to http://localhost:8080/index.html in your browser.

